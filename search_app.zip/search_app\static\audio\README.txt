Add background audio for the site

Place an MP3 file at:

/home/yourusername/mysite/static/audio/tukband.mp3

Or, within the project folder, copy your audio to:

static/audio/tukband.mp3

Notes:
- Use an MP3 (or OGG) file for broad browser support.
- Keep the file reasonably small (under 5MB recommended) to avoid slow page loads.
- Due to browser autoplay rules, music may not start until users interact with the page. The site adds a floating Play/Pause button so visitors can start the music.
- If you prefer an external audio URL, replace the `src` in `templates/index.html` audio source with the external URL.

Attribution: Ensure you have the rights to use any music you host.
