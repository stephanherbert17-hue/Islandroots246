PythonAnywhere deployment checklist

1) Upload your code
- Git (recommended): `cd ~` then `git clone <repo-url> mysite` or push files via the Files page to `/home/ISLANDRPPTS246TUKBAND/mysite`.
- Confirm `app.py`, `requirements.txt`, `runtime.txt`, `templates/` and `static/` are present under `/home/ISLANDRPPTS246TUKBAND/mysite`.

2) Create & activate a virtualenv (Python 3.11)
Open a Bash console on PythonAnywhere and run:

```bash
python3.11 -m venv ~/venv-3.11
source ~/venv-3.11/bin/activate
pip install -U pip
pip install -r ~/mysite/requirements.txt
```

3) WSGI configuration
- Open the Web tab → WSGI configuration file: `/var/www/islandrppts246tukband_pythonanywhere_com_wsgi.py` and replace its contents with the snippet in `pythonanywhere_wsgi.py` or paste the snippet shown there.
- Ensure the `path` variable points to `/home/ISLANDRPPTS246TUKBAND/mysite` and that the import uses your Flask app variable (usually `from app import app as application`).

4) Virtualenv path in Web tab
- In the Web tab, enter the virtualenv path: `/home/ISLANDRPPTS246TUKBAND/venv-3.11` (then click Save).

5) Static files mapping
- In the Web tab add a static mapping:
  - URL: `/static/`
  - Directory: `/home/ISLANDRPPTS246TUKBAND/mysite/static`

6) Environment variables (Web → Environment variables)
Add these keys with your values:
- `SENDER_EMAIL` (sender SMTP email)
- `SENDER_PASSWORD` (SMTP password or app password)
- `SMTP_HOST` (e.g. smtp.gmail.com)
- `SMTP_PORT` (e.g. 587)
- `SMTP_USE_TLS` (true/false)
- `BAND_EMAIL` (island.roots.246.tukband@gmail.com)
- `SECRET_KEY` (random string)
- `ADMIN_PASSWORD` (set an admin password)

7) Force HTTPS & Reload
- Enable "Force HTTPS" in the Web tab.
- Click the `Reload` button to restart the app.

8) Troubleshooting / logs
- If the site fails to start, check the error log at:
  `/var/log/islandrppts246tukband.pythonanywhere.com.error.log` (link in the Web tab)
- Common errors:
  - `ModuleNotFoundError`: virtualenv not set or packages not installed.
  - Import errors: wrong `path` in WSGI file — ensure it matches your `mysite` location.
  - SMTP auth errors: verify credentials and app-passwords for Gmail.

9) Monthly keep-alive note
- Free accounts must click "Run until 1 month from today" at least once per month or the site will be disabled on the listed date. Consider upgrading if you prefer not to manage this.

If you want, I can generate a ready-to-paste WSGI file and a small shell script you can run in the PythonAnywhere Bash console (see files added). If the app fails after reload, upload the error log and I will fix it.