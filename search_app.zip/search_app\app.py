import os
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import Flask, render_template, request, session, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret')

BAND_EMAIL = os.environ.get('BAND_EMAIL', 'island.roots.246.tukband@gmail.com')
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', os.environ.get('SMTP_USER', 'island.roots.246.tukband@gmail.com'))
SENDER_PASSWORD = os.environ.get('SENDER_PASSWORD', os.environ.get('SMTP_PASSWORD', 'pdxpryjqbukmothb'))
SMTP_HOST = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', 587))
SMTP_USE_TLS = os.environ.get('SMTP_USE_TLS', 'true').lower() in ('1', 'true', 'yes')
MAIL_FROM = os.environ.get('MAIL_FROM', SENDER_EMAIL)
AUTHORIZED_ADMINS = {
    'stephanherbert61@gmail.com',
    'stephanherbert17@gmail.com',
    'island.roots.246.tukband@gmail.com',
}
OWNER_EMAILS = {'stephanherbert17@gmail.com'}
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD')
booking_requests = []


def send_email(subject, plain_text, html_text, to_email, reply_to=None):
    if not SMTP_HOST or not SENDER_PASSWORD:
        print('[EMAIL ERROR] SMTP settings are incomplete. Cannot send email.')
        return False

    msg = MIMEMultipart('alternative')
    msg['From'] = MAIL_FROM
    msg['To'] = to_email
    msg['Subject'] = subject
    if reply_to:
        msg['Reply-To'] = reply_to

    msg.attach(MIMEText(plain_text, 'plain'))
    msg.attach(MIMEText(html_text, 'html'))

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30)
        server.ehlo()
        if SMTP_USE_TLS:
            server.starttls()
            server.ehlo()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.sendmail(SENDER_EMAIL, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as exc:
        print(f'[EMAIL ERROR] Failed to send email to {to_email}: {exc}')
        return False


def send_booking_notification(client_name, client_email, client_phone, event_type, event_date, start_time, end_time, location, budget, event_details):
    subject = f'🚨 New Tuk Band Booking Request from {client_name}!'
    plain_text = (
        f'You have received a fresh booking request from {client_name}!\n\n'
        f'Event type: {event_type}\n'
        f'Date: {event_date}\n'
        f'Time: {start_time} to {end_time}\n'
        f'Location: {location}\n'
        f'Budget offered: BBD {budget}\n'
        f'Client email: {client_email}\n'
        f'Client phone: {client_phone}\n\n'
        f'Details:\n{event_details}\n\n'
        f'Reply directly to the client to confirm their booking request.\n'
    )
    html_text = (
        f'<html><body style="font-family: Arial, sans-serif; color:#2c3e50;">'
        f'<h2 style="color:#002664;">Islandroots.246 Tuk Band Booking Alert</h2>'
        f'<p><strong>Client Name:</strong> {client_name}</p>'
        f'<p><strong>Client Email:</strong> {client_email}</p>'
        f'<p><strong>Contact Phone:</strong> {client_phone}</p>'
        f'<p><strong>Event Type:</strong> {event_type}</p>'
        f'<p><strong>Date:</strong> {event_date}</p>'
        f'<p><strong>Time:</strong> {start_time} to {end_time}</p>'
        f'<p><strong>Location:</strong> {location}</p>'
        f'<p><strong>Budget offered:</strong> BBD {budget}</p>'
        f'<h3 style="color:#FFC000;">Event Details</h3>'
        f'<p style="white-space: pre-wrap;">{event_details}</p>'
        f'<hr style="border:none;border-top:2px dashed #002664;margin:20px 0;">'
        f'<p style="font-size:0.95rem;">This is an automated booking notification. A director will review it and reply as soon as possible.</p>'
        f'</body></html>'
    )
    return send_email(subject, plain_text, html_text, BAND_EMAIL, reply_to=client_email)


def send_auto_response(client_name, client_email, methods):
    methods_list = ', '.join(methods) if methods else 'WhatsApp, email, or a direct call'
    subject = '📣 Islandroots.246 Tuk Band — We received your request'
    plain_text = (
        f'Hello {client_name},\n\n'
        f'Thank you for booking Islandroots.246 Tuk Band! Our director has reviewed your request and will reach out to you shortly via {methods_list}.\n\n'
        f'If you have any immediate questions, reply directly to this message.\n\n'
        f'— Islandroots.246 Team'
    )
    html_text = (
        f'<html><body style="font-family: Arial, sans-serif; color:#2c3e50;">'
        f'<h2 style="color:#002664;">Your Tuk Band request is in good hands!</h2>'
        f'<p>Hi {client_name},</p>'
        f'<p>Thanks for reaching out to Islandroots.246 Tuk Band.</p>'
        f'<p>One of our directors has seen your booking and will contact you soon via <strong>{methods_list}</strong>.</p>'
        f'<p style="margin-top:24px;">We look forward to bringing authentic Bajan rhythm to your event.</p>'
        f'<p>— Islandroots.246 Team</p>'
        f'</body></html>'
    )
    return send_email(subject, plain_text, html_text, client_email, reply_to=BAND_EMAIL)


def parse_booking_datetime(date_str, time_str):
    try:
        return datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
    except ValueError:
        return None


def times_overlap(start1, end1, start2, end2):
    return start1 < end2 and start2 < end1


def check_booking_conflict(event_date, start_time, end_time):
    requested_start = parse_booking_datetime(event_date, start_time)
    requested_end = parse_booking_datetime(event_date, end_time)
    if not requested_start or not requested_end or requested_start >= requested_end:
        return True, 'Please provide a valid date and time range.'

    for booking in booking_requests:
        if booking.get('event_date') != event_date:
            continue
        existing_start = parse_booking_datetime(booking['event_date'], booking['start_time'])
        existing_end = parse_booking_datetime(booking['event_date'], booking['end_time'])
        if existing_start and existing_end and times_overlap(requested_start, requested_end, existing_start, existing_end):
            return True, (
                f'The requested time conflicts with an existing booking on {booking["event_date"]} ' 
                f'from {booking["start_time"]} to {booking["end_time"]} at {booking["location"]}.'
            )

    return False, None


def is_admin(email):
    return bool(email and email in AUTHORIZED_ADMINS)


def is_owner(email):
    return bool(email and email in OWNER_EMAILS)


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        if is_admin(email) and (not ADMIN_PASSWORD or password == ADMIN_PASSWORD):
            session['admin_email'] = email
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin credentials.')

    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_email', None)
    return redirect(url_for('admin_login'))


@app.route('/admin', methods=['GET'])
def admin_dashboard():
    admin_email = session.get('admin_email')
    if not is_admin(admin_email):
        return redirect(url_for('admin_login'))

    return render_template(
        'admin.html',
        admin_email=admin_email,
        booking_requests=booking_requests,
        is_owner=is_owner(admin_email),
        admin_list=sorted(AUTHORIZED_ADMINS),
    )


@app.route('/admin/grant', methods=['POST'])
def grant_admin():
    admin_email = session.get('admin_email')
    if not is_owner(admin_email):
        return redirect(url_for('admin_login'))

    new_admin = request.form.get('new_admin_email', '').strip().lower()
    if new_admin:
        AUTHORIZED_ADMINS.add(new_admin)
        flash(f'Added {new_admin} as an admin.')
    else:
        flash('Please enter a valid email to grant admin access.')

    return redirect(url_for('admin_dashboard'))


@app.route('/admin/update-request', methods=['POST'])
def update_request():
    admin_email = session.get('admin_email')
    if not is_admin(admin_email):
        return redirect(url_for('admin_login'))

    try:
        request_index = int(request.form.get('request_index', -1))
        booking = booking_requests[request_index]
    except (ValueError, IndexError):
        flash('Invalid booking request selected.')
        return redirect(url_for('admin_dashboard'))

    methods = []
    if request.form.get('method_whatsapp'):
        methods.append('WhatsApp')
    if request.form.get('method_email'):
        methods.append('Email')
    if request.form.get('method_call'):
        methods.append('Direct Call')
    if not methods:
        methods = ['WhatsApp', 'Email', 'Direct Call']

    response_sent = send_auto_response(booking['name'], booking['email'], methods)
    booking['status'] = 'Reviewed'
    booking['reviewed_by'] = admin_email
    booking['response_sent'] = response_sent
    booking['response_methods'] = methods
    booking['updated_at'] = datetime.now().strftime('%Y-%m-%d %H:%M')

    if response_sent:
        flash('Automated response sent to the client.')
    else:
        flash('Automated response failed to send. Please check SMTP settings.')

    return redirect(url_for('admin_dashboard'))


@app.route('/', methods=['GET'])
def index():
    booked_schedule = sorted(booking_requests, key=lambda b: (b['event_date'], b['start_time']))
    return render_template('index.html', success=False, booked_schedule=booked_schedule, form_data={})


@app.route('/book', methods=['POST'])
def handle_booking():
    client_name = request.form.get('name')
    client_email = request.form.get('email')
    client_phone = request.form.get('phone')
    event_type = request.form.get('event_type')
    event_date = request.form.get('event_date')
    start_time = request.form.get('start_time')
    end_time = request.form.get('end_time')
    location = request.form.get('location')
    budget = request.form.get('budget', '').strip() or '800'
    event_details = request.form.get('details')

    form_data = {
        'name': client_name,
        'email': client_email,
        'phone': client_phone,
        'event_type': event_type,
        'event_date': event_date,
        'start_time': start_time,
        'end_time': end_time,
        'location': location,
        'budget': budget,
        'details': event_details,
    }

    if not (event_date and start_time and end_time and location):
        conflict_message = 'Please select the event date, start time, end time, and location before submitting.'
        booked_schedule = sorted(booking_requests, key=lambda b: (b['event_date'], b['start_time']))
        return render_template(
            'index.html',
            success=False,
            conflict=True,
            conflict_message=conflict_message,
            form_data=form_data,
            booked_schedule=booked_schedule,
        )

    conflict, conflict_message = check_booking_conflict(event_date, start_time, end_time)
    if conflict:
        booked_schedule = sorted(booking_requests, key=lambda b: (b['event_date'], b['start_time']))
        return render_template(
            'index.html',
            success=False,
            conflict=True,
            conflict_message=conflict_message,
            form_data=form_data,
            booked_schedule=booked_schedule,
        )

    print('\n' + '=' * 55)
    print('[SYSTEM NOTICE] NEW ISLANDROOTS.246_TUKBAND BOOKING')
    print(f'Client Target: {client_name} ({client_email} / {client_phone})')
    print(f'Booking For:  {event_type}')
    print(f'Date/Time:     {event_date} {start_time}-{end_time}')
    print(f'Location:      {location}')
    print(f'Budget:        BBD {budget}')
    print(f'Details:       {event_details}')
    print('-' * 55)
    print('[BOT DISPATCH] Alert routed to Stephan Herbert & Board.')
    print(f'[STATUS] Waiting on Director approval for {event_type}.')
    print('=' * 55 + '\n')

    email_sent = send_booking_notification(
        client_name,
        client_email,
        client_phone,
        event_type,
        event_date,
        start_time,
        end_time,
        location,
        budget,
        event_details,
    )

    booking_requests.append({
        'name': client_name,
        'email': client_email,
        'phone': client_phone,
        'event_type': event_type,
        'event_date': event_date,
        'start_time': start_time,
        'end_time': end_time,
        'location': location,
        'budget': budget,
        'details': event_details,
        'email_sent': email_sent,
        'status': 'New' if email_sent else 'New (email failed)',
        'reviewed_by': None,
        'response_sent': False,
        'response_methods': [],
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'updated_at': None,
    })

    booked_schedule = sorted(booking_requests, key=lambda b: (b['event_date'], b['start_time']))
    return render_template('index.html', success=True, email_sent=email_sent, booked_schedule=booked_schedule, form_data={})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
