# Drop this snippet into /var/www/islandrppts246tukband_pythonanywhere_com_wsgi.py
import sys
path = '/home/ISLANDRPPTS246TUKBAND/mysite'
if path not in sys.path:
    sys.path.insert(0, path)

# Activate virtualenv if you created one at /home/ISLANDRPPTS246TUKBAND/venv-3.11
activate_this = '/home/ISLANDRPPTS246TUKBAND/venv-3.11/bin/activate_this.py'
try:
    with open(activate_this) as f:
        code = compile(f.read(), activate_this, 'exec')
        exec(code, dict(__file__=activate_this))
except Exception:
    # If virtualenv activation fails, the Web tab virtualenv setting will still work.
    pass

# Import the Flask application as `application` (PythonAnywhere expects this name)
from app import app as application
