#!/bin/bash
# Run these commands in a PythonAnywhere Bash console (adjust venv name/path as needed)
python3.11 -m venv ~/venv-3.11
source ~/venv-3.11/bin/activate
python -m pip install -U pip
pip install -r ~/mysite/requirements.txt
cd ~/mysite
python -c "from app import app; print('import OK')"
# When done, visit the Web tab and set the virtualenv path to /home/ISLANDRPPTS246TUKBAND/venv-3.11 then Reload the web app.
