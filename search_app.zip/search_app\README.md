# Islandroots.246 Tuk Band

This project is a Flask booking site for Islandroots.246 Tuk Band.

## Goal
Make the site available on a free public domain or free subdomain and improve search discovery.

## Recommended deployment path
1. Create a free account on a Python-friendly host such as Render, Railway, or Fly.io.
2. Connect this repository or upload the project files.
3. Configure the service to run `python app.py`.
4. Use the service's free subdomain (for example, `islandroots-246.render.com`) as your live URL.

## Free domain options
- Use a host-provided free subdomain on Render, Railway, Fly.io, or PythonAnywhere. That gives you a live public URL accessible anywhere.
- If you want a custom free domain name, register a free domain at [Freenom](https://www.freenom.com) and point its DNS records to the host.

## Search visibility
To make the page easier to find with one search:
- Keep the site title and description accurate.
- Use the band name in the page title and meta tags.
- Add the live URL to Google Search Console once deployed.
- Share the live URL on social media and Instagram so search engines index it quickly.

## Admin panel
A protected admin panel is available:
- Login at `/admin/login`
- Accessible for the following email addresses only:
  - `stephanherbert61@gmail.com`
  - `stephanherbert17@gmail.com`
  - `island.roots.246.tukband@gmail.com`
- You can optionally set `ADMIN_PASSWORD` if you want a shared password.

## SMTP email notes
The app supports booking notification email delivery. To ensure email is actually delivered, configure SMTP with a valid mail provider and login credentials.

Set these environment variables on the host:
- `SMTP_HOST` (required)
- `SMTP_PORT` (required)
- `SENDER_EMAIL` or `SMTP_USER` (required for Gmail/SendGrid)
- `SENDER_PASSWORD` or `SMTP_PASSWORD` (required for Gmail/SendGrid)
- `BAND_EMAIL` (optional, default: `island.roots.246.tukband@gmail.com`)
- `MAIL_FROM` (optional, defaults to `SENDER_EMAIL`)
- `SMTP_USE_TLS` (optional, default: `true`)

Example for Gmail App Password:
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SENDER_EMAIL=your-email@gmail.com
SENDER_PASSWORD=your-app-password
BAND_EMAIL=island.roots.246.tukband@gmail.com
```

Example for SendGrid:
```bash
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SENDER_EMAIL=apikey
SENDER_PASSWORD=YOUR_SENDGRID_API_KEY
BAND_EMAIL=island.roots.246.tukband@gmail.com
```

## Local run
```bash
python app.py
```

Then open `http://127.0.0.1:5000/`.
